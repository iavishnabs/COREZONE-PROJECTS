# shoppers functions

from flask import *
from database import *
import uuid

shop = Blueprint("shop",__name__)

@shop.route("/shop_home")
def shop_home():

	data={}
	a = session['Sid']
	q = "select * from shop where shop_id='%s'"%(a) 
	data['cur_shop']=select(q) 

	return render_template("shop_pages/shop_home.html",data=data)

@shop.route("/productmanage",methods=['get','post'])
def productmanage():
	data={}
	a = session['Sid']
	q1  = "select * from products where shop_id='%s'"%(a)
	data['pdts'] = select(q1)

	q2  = "select * from category"
	data['cats'] = select(q2)

	q3  = "select * from vendor"
	data['vend'] = select(q3)

	q4 = "select * from shop where shop_id='%s'"%(a)
	data['shops'] = select(q4)

	q = "SELECT * FROM products INNER JOIN category USING(cid) INNER JOIN vendor USING(vid) INNER JOIN shop USING(shop_id)where shop_id='%s'"%(a)
	data['view_all'] = select(q) 

	if "action" in request.args:
		action = request.args['action']
		pid = request.args['pid']
	else:
		action = None

	if action == "delete":
		delq  = "delete from products where pid='%s'"%(pid)
		delete(delq)
		return redirect(url_for("shop.productmanage")) 
	if action == "update":
		upq = "select * from products inner join category using(cid) inner join vendor using(vid) inner join shop using(shop_id) where pid='%s'"%(pid)
		data['updates']=select(upq)

	# add 
	if "add" in request.form:
		vendor = request.form['vend']
		category = request.form['catg']
		shop = request.form['shops']
		pname = request.form['pname']
		details = request.form['details']
		price = request.form['price']

		image  = request.files['image']
		path="static/images/"+str(uuid.uuid4())+image.filename
		image.save(path)
		
		
		q = "insert into products values(null,'%s','%s','%s','%s','%s','%s','%s')"%(vendor,category,shop,pname,details,price,path)
		insert(q)
		return redirect(url_for("shop.productmanage"))

	if "update" in request.form:
		vendor =  request.form['vend']
		category = request.form['catg']
		shop = request.form['shops']
		pname = request.form['pname']
		details = request.form['details']
		price = request.form['price']
		image = request.files['image']
		path = "static/images/"+str(uuid.uuid4())+image.filename
		image.save(path)

		q = "update products set `vid`='%s',`cid`='%s',`shop_id`='%s',`pname`='%s',`details`='%s',`price`='%s',`image`='%s' where pid='%s'"%(vendor,category,shop,pname,details,price,path,pid)
		update(q)
		return redirect(url_for("shop.productmanage"))
	# update
	return render_template("shop_pages/productmanage.html",data=data) 


@shop.route('/shop_stockmanage',methods=['get','post'])
def shop_stockmanage():
	a = session['Sid']
	data = {}
	q = "select * from products where shop_id='%s'"%(a)
	data['pdts_view']=select(q)

	if "add" in request.form:
		pname =  request.form['pname']
		qty =  request.form['qty']
		dt =  request.form['dt']

		add = "insert into stocks values(null,'%s','%s','%s')"%(pname,qty,dt)
		insert(add)
		return redirect(url_for("shop.shop_stockmanage"))

	q2 = "select * from stocks inner join products using(pid) where shop_id='%s'"%(a)
	data['stocks']=select(q2)

	if "action" in request.args:
		action = request.args['action']
		stock_id = request.args['stock_id']
	else:
		action = None

	if action == "delete":
		delq = "delete from stocks where stock_id='%s'"%(stock_id)
		delete(delq)
		return redirect(url_for("shop.shop_stockmanage")) 

	if action == "update":
		upq = "select * from stocks where stock_id='%s'"%(stock_id)
		data['updates']=select(upq)

	if "update" in request.form:
		pname =  request.form['pname']
		qty =  request.form['qty']
		dt =  request.form['dt']

		q = "update stocks set pid='%s',quantity='%s',date_time='%s' where stock_id='%s'"%(pname,qty,dt,stock_id)
		update(q)
		return redirect(url_for("shop.shop_stockmanage")) 
	return render_template("shop_pages/shop_stockmanage.html",data=data)

@shop.route('/shop_viewcategory')
def shop_viewcategory():
	data = {}
	q = "select * from category"
	data['view'] = select(q) 
	return render_template("shop_pages/shop_viewcategory.html",data=data)


@shop.route('/shop_replaycomplaint',methods=['get','post'])
def shop_replaycomplaint():
	a = session['Sid']
	data = {}
	q = "select * from complaint inner join shop using(shop_id) where shop_id='%s'"%(a)
	data['view'] = select(q)

	if "action" in request.args:
		action = request.args['action']
		complaint_id = request.args['complaint_id']
	else:
		action= None

	if action == "update":
		q = "select * from complaint where complaint_id='%s'"%(complaint_id)
		data['updates']= select(q)

	if "replay" in request.form:
		rpl = request.form['rpl']
		q = "update `complaint` set replay='%s' where complaint_id='%s'"%(rpl,complaint_id)
		update(q)
		return redirect(url_for("shop.shop_replaycomplaint"))

	return render_template("shop_pages/shop_replaycomplaint.html",data=data)

@shop.route('/shopordercheck',methods=['get','post'])
def shopordercheck():
	data= {}
	sh = session['Sid']

	q= "SELECT shop_id,pid,pname,order_status,User_id FROM order_details INNER JOIN order_master USING(ord_master_id) INNER JOIN shop WHERE shop_id='%s'"%(sh)
	data['ord']=select(q)

	if "action" in request.args:
		action = request.args['action']
		pid = request.args['pid']
		User_id =request.args['User_id']

		if action == "accept":
			q1 = "SELECT * FROM delivery_boys"
			data['delboys'] = select(q1)

			q2 = "SELECT * FROM products WHERE pid='%s'"%(pid)
			data['pdt'] = select(q2)

			q3 = "select * from users where User_id='%s'"%(User_id)
			data['usr'] = select(q3) 
			u = data['usr']
			us = data['usr'][0]['User_id']

			q4 = "SELECT ord_master_id FROM order_master WHERE User_id='%s'"%(User_id)
			data['ordmaster'] = select(q4)
			res = data['ordmaster']
			ord_id =res[0]['ord_master_id']
		

		if "assign" in request.form:
			boy_id = request.form['boy_id']

			q = "insert into set_to_deliver values(null,'%s','%s','%s','pending')"%(boy_id,ord_id,pid)
			insert(q)

			q2 = "UPDATE order_details INNER JOIN order_master SET order_status='set_to_deliver' WHERE  pid='%s' AND User_id='%s'"%(pid,us)
			update(q2)
			return redirect(url_for("shop.shopordercheck"))

	return render_template("shop_pages/shopordercheck.html",data=data)


@shop.route('/shopviewpayment')
def shopviewpayment():
	data={}
	sh = session['Sid']
	q = "SELECT * FROM order_master INNER JOIN order_details USING(ord_master_id) INNER JOIN products USING(pid) INNER JOIN shop USING(shop_id) WHERE shop_id='%s'"%(sh)
	data['payments']=select(q)
	return render_template("shop_pages/shopviewpayment.html",data=data)



