from flask import * ###
from public import public ###
from user import user
from shops import shop
from admin import admin
from deliveryboy import delv_boy

from flask_login import login_required, logout_user 


app = Flask(__name__) ####
app.register_blueprint(public)
app.register_blueprint(delv_boy)
app.register_blueprint(user)
app.register_blueprint(shop)
app.register_blueprint(admin)

app.secret_key="dell"


app.run(debug=True,port="5006") #####