# public methods
from flask import *
from database import *
from admin import admin_home
from shops import shop_home
from user import user_home
from deliveryboy import delivery_home

public = Blueprint('public',__name__) 

@public.route('/')
def index(): 
	return render_template('index.html')

@public.route('/user_login',methods=['get','post']) 
def user_login(): 
	if 'login' in request.form:
		uname = request.form['uname']
		pasw = request.form['pasw']

		q = "select * from `login` where `username` = '%s' and `password`='%s'"%(uname,pasw)
		res = select(q) 
		if res:
			session['lid']=res[0]['Login_id'] 

			if res[0]['usertype'] == "user":
				z="select * from users where Login_id='%s'"%(session['lid'])
				des=select(z)
				if des:
					session['Uid']=des[0]['User_id'] 
					return redirect(url_for("user.user_home"))
			
			elif res[0]['usertype'] == "deliveryboy":
				d = "select * from delivery_boys where Login_id='%s'"%(session['lid'])
				dby = select(d)
				if dby:
					session['bid'] = dby[0]['boy_id']
					return redirect(url_for("delv_boy.delivery_home"))

			elif res[0]['usertype'] == "shop":
				s = "select * from shop where Login_id='%s'"%(session['lid'])
				sh = select(s)
				print(sh)
				if sh:
					session['Sid'] = sh[0]['shop_id']
					return redirect(url_for("shop.shop_home"))

			elif res[0]['usertype'] == "admin":
				return redirect(url_for("admin.admin_home"))
		else:
			return '''<script>alert("Invalid Credential")</script>'''
	return render_template('public_pages/user_login.html') 


@public.route('/user_register',methods=['get','post'])
def user_register():
	if 'register' in request.form:
		fname = request.form['fname']  
		lname = request.form['lname'] 
		uname = request.form['uname'] 
		pasw = request.form['pasw']             
		email = request.form['email'] 
		phone =  request.form['phone'] 
		adr = request.form['adr'] 
		dist = request.form['dist']
		pincode = request.form['pincode']

		q1 = "insert into `login` values(null,'%s','%s','user')"%(uname,pasw)
		res = insert(q1)

		q2 = "insert into `users` values(null,'%s','%s','%s','%s','%s','%s','%s','%s')"%(res,fname,lname,adr,pincode,phone,dist,email)
		insert(q2)
		return redirect(url_for("public.user_login")) 
	return render_template('public_pages/user_register.html') 


@public.route('/shop_register',methods=['get','post'])
def shop_register():
	if "register" in request.form:
		uname  = request.form['uname']
		pasw = request.form['pasw']
		shopname = request.form['shopname']
		place = request.form['place']
		landmark = request.form['landmark']
		email = request.form['email']
		phone = request.form['phone']

		q = "insert into login values(null,'%s','%s','shop')"%(uname,pasw)
		res = insert(q)

		q2 = "insert into shop values(null,'%s','%s','%s','%s','%s','%s','pending')"%(res,shopname,place,landmark,phone,email)
		insert(q2) 
		return redirect(url_for("public.user_login")) 
		
	return render_template('public_pages/shop_register.html')