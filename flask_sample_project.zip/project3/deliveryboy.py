# delivery boys functions
from flask import *
from database import *

delv_boy = Blueprint("delv_boy",__name__)

@delv_boy.route('/delivery_home')
def delivery_home():
	data={}
	q = "select * from `delivery_boys` where `boy_id`='%s'"%(session['bid'])
	data['cur_delby']=select(q)
	return render_template("delvboy_pages/delv_home.html",data=data)  


@delv_boy.route("/delvboyorderview")
def delvboyorderview():
	data={}
	d = session['bid']
	q = "SELECT *,User_id FROM set_to_deliver INNER JOIN order_master USING(ord_master_id) WHERE boy_id='%s'"%(d)
	data['orderpending'] = select(q)
	stats = data['orderpending'][0]['delstatus']
	data['st'] = stats

	return render_template("delvboy_pages/delvboyorderview.html",data=data)

@delv_boy.route("/delvboyorderpickup")
def delvboyorderpickup():
	data={}
	d = session['bid']
	q = "SELECT *,User_id FROM set_to_deliver INNER JOIN order_master USING(ord_master_id) WHERE boy_id='%s'"%(d)
	data['orderpending'] = select(q)
	stats = data['orderpending'][0]['delstatus']
	data['st'] = stats

	if "action" in request.args:
		action = request.args['action']
		User_id = request.args['User_id']
		pid= request.args['pid'] 

		if action == "pickup":
			q = "update `set_to_deliver` inner join order_master using(ord_master_id) set `delstatus`='pickedup' where pid='%s' and User_id='%s'"%(pid,User_id)
			update(q)
			q2 = "UPDATE `order_details` inner JOIN order_master USING(ord_master_id) SET order_status='out for delivery' WHERE pid='%s' AND User_id='%s'"%(pid,User_id)
			update(q2)
			return redirect(url_for("delv_boy.delvboyorderpickup"))

	if "actionn" in request.args:
		action = request.args['actionn']
		ord_master_id= request.args['ord_master_id']
		boy_id= request.args['boy_id']
		User_id = request.args['User_id']
		pid= request.args['pid'] 

		if action == "delivered":
			q = "insert into delivery values(null,'%s','%s','delivered',curdate())"%(ord_master_id,boy_id)
			insert(q)
			
			q2 = "UPDATE `order_details` inner JOIN order_master USING(ord_master_id) SET order_status='delivered' WHERE pid='%s' AND User_id='%s'"%(pid,User_id) 
			update(q2)
			q = "update `set_to_deliver` inner join order_master using(ord_master_id) set `delstatus`='delivered' where pid='%s' and User_id='%s'"%(pid,User_id)
			update(q)

			return redirect(url_for("delv_boy.delivery_home"))

	return render_template("delvboy_pages/delvboyorderpickup.html",data=data)

