# users functions

from flask import *
from database import *
from datetime import *
from flask_login import  login_required

user = Blueprint("user",__name__)

@login_required
@user.route("/user_home")
def user_home():
	data={}
	qs = "select * from users where User_id='%s'"%(session['Uid'])
	data['cur_user']=select(qs)
	return render_template("userpages/user_home.html",data=data)

@user.route("/usersendcomplaint",methods=['get','post'])
def usersendcomplaint():
	data = {}
	q1 = "select * from shop"
	data['shops'] = select(q1)
	if "send" in request.form:
		shopname = request.form['shopname']
		complaint = request.form ['complaint']
		date_time = request.form['dt']

		q = "insert into complaint values(null,'%s','%s','Pending','%s','%s')"%(session['Uid'],complaint,date_time,shopname)
		insert(q)

		return redirect(url_for("user.userviewreply"))
	return render_template("userpages/usersendcomplaint.html",data=data)

@user.route("/userviewreply")
def userviewreply():
	data={}
	q = "select * from complaint inner join shop using(shop_id)"
	data['view']=select(q)

	return render_template("userpages/userviewreply.html",data=data)

@user.route("/userviewshop")
def userviewshop():
	data = {}
	q = "select * from shop"
	data['shopview'] = select(q)
	return render_template("userpages/userviewshop.html",data=data)

@user.route("/userviewproduct")
def userviewproduct():
	data = {}
	u = session['Uid']

	if "action" in request.args:
		action = request.args['action']
		a=request.args['shop_id'] 
	else:
		action = None

	if action == "viewp":
		q = "select * from products inner join shop using(shop_id) inner join vendor using(vid) inner join category using(cid) where shop_id='%s'"%(a) 
		data['pdtview']=select(q) 

	if "actionn" in request.args:
		acct =request.args['actionn']
		pid = request.args['pid']
		shop_id = request.args['shop_id']
		price = request.args['price']

		if acct == "addtocart":
			q = "insert into cart values(null,'%s','%s','%s','1')"%(session['Uid'],pid,shop_id)
			insert(q)
			print(q)
			return redirect(url_for("user.userviewcart"))
		else:
			pass
	if "act" in request.args:
		pass

	return render_template("userpages/userviewproduct.html",data=data) 

@user.route("/userviewcart", methods=['get','post'])
def userviewcart():
	data = {} 
	total_amount = 0
	a = session['Uid']
	
	q ="SELECT *, `cart`.`quantity` AS oq, `stocks`.`quantity` AS pq FROM cart INNER JOIN products USING(pid)INNER JOIN stocks USING(pid) INNER JOIN shop ON(products.shop_id=shop.shop_id) WHERE User_id='%s'"%(a)
	data['cartitems'] = select(q)

	res = data['cartitems'] 
	if res:
		for i in res:
			q = int(i['oq'])
			p = float(i['price'])
			total_amount += q * p
	else:
		print("!!!!!!1no amount!!!!!!!!!")

	if "action" in request.args:
		action = request.args['action']
		cart_id = request.args['cart_id']
	else:
		action = None
	if action == "delete":
		q = "delete from cart where cart_id='%s'"%(cart_id)
		delete(q)
		return redirect(url_for("user.userviewcart"))
	
	if "actions" in request.args:
		action = request.args['actions']
		cart_id = request.args['cart_id'] 

		if action == "decrement":
			qnt = "select * from cart inner join products using(pid) where cart_id='%s'"%(cart_id)
			data['q']= select(qnt)
			res = data['q']
			if res:
				if int(res[0]['quantity']) == 1:
					print("minimum quantity should be one")
				else:
					up = "update cart set quantity=quantity-1 where cart_id='%s'"%(cart_id)
					update(up)
					print("decreased by 1")
		if action == "increment":
			qnt = "select * from cart inner join products using(pid) where cart_id='%s'"%(cart_id)
			data['q'] = select(qnt)
			res = data['q'][0]['quantity'] # cart quantity

			st = data['q'][0]['pid']
			
			stcks = "SELECT quantity FROM stocks iner JOIN products USING(pid) WHERE pid='%s'"%(st)
			data['s'] = select(stcks)
			ress = int(data['s'][0]['quantity']) # stocks quantity  

			if int(res) < ress:
				up = "update cart set quantity=quantity+1 where cart_id='%s'"%(cart_id)
				update(up)
				print("!!!!!increased by 1!!!!!!!!!")
			else:
				print("!!!!!!quantity is greater than stocks!!!!!!") 
	return render_template("userpages/userviewcart.html",data=data, total_amount=total_amount)

@user.route('/userviewproductdetails')
def userviewproductdetails():
	data={}

	if "action" in request.args:
		action = request.args['action']
		pid =  request.args['pid'] 

	if action == "viewmore":
		q = "select * from products where pid='%s'"%(pid)
		data['viewmore'] = select(q)
	return render_template("userpages/userviewproductdetails.html",data=data)

@user.route('/userplaceorder',methods=['get','post'])
def userplaceorder():
	user = session['Uid']
	data = {}
	tamount = request.args['total_amount']
	
	if "pay" in request.form:
		account_number = request.form['account_number']
		Card_number = request.form['Card_number']
		cvv_number = request.form['cvv_number']
		pin_number = request.form['pin_number']
		acc_holder = request.form['acc_holder']
		amount = request.form['amount']

		q = "insert into bank_account values(null,'%s','%s','%s','%s','%s','%s','%s')"%(account_number,Card_number,cvv_number,pin_number,acc_holder,amount,user)
		res= insert(q)
		print("!!!!!!!!!!successfully done payment!!!!!!1")

		if res:
			q = "insert into order_master values(null,'%s',curdate(),'%s','Paid')"%(user,amount)
			ress = insert(q)
			print("!!!!successfully added to order_master table!!!!!") 

			qs = "SELECT ord_master_id FROM order_master WHERE User_id='%s'"%(user)
			ord_id = select(qs)
			
			od_id = ord_id[0]['ord_master_id']
			
			q ="SELECT *, `cart`.`quantity` AS oq, `stocks`.`quantity` AS pq FROM cart INNER JOIN products USING(pid)INNER JOIN stocks USING(pid) INNER JOIN shop ON(products.shop_id=shop.shop_id) WHERE User_id='%s'"%(user) 
			
			data['cartitems'] = select(q)
			res = data['cartitems'] 
			print(res[0]['pid'])

			for i in res:
				p = i['pid']
				q = i['oq']
				amnt = int(i['oq']) * int(i['price'])
				print("items:::::::::",p,q,amnt) 

				q = "insert into order_details values(null,'%s','%s','%s','%s','pending')"%(od_id,p,amnt,q)
				insert(q)

				d = "DELETE FROM cart WHERE User_id='%s'"%(user)
				delete(d)
				print("!!! Items in cart is deleted  !!!!!!")
			return redirect(url_for("user.usermyorder"))

	return render_template('userpages/userplaceorder.html',tamount=tamount)

@user.route('/usermyorder')
def usermyorder():
	# pending orders
	user = session['Uid']
	data = {}
	q = "SELECT * FROM order_details INNER JOIN order_master USING(ord_master_id) INNER JOIN products USING(pid) WHERE order_status='pending' AND  User_id='%s'"%(user)
	data['us']=select(q)

	return render_template("userpages/usermyorder.html",data=data)

@user.route("/userdeliveredorders")
def userdeliveredorders():
	user = session['Uid']
	data = {}
	q = "SELECT * FROM order_details INNER JOIN order_master USING(ord_master_id) INNER JOIN products USING(pid) WHERE order_status='delivered' AND  User_id='%s'"%(user)
	data['us']=select(q)

	if "action" in request.args:
		action = request.args['action']
		pid = request.args['pid']

		if action == "rate":
			pass

	return render_template('userpages/userdeliveredorders.html',data=data)

@user.route("/userproductsuggest")
def userproductsuggest():
	data= {}
	q = "select * from products"
	data['pdts']=select(q)
	return render_template("userpages/userproductsuggest.html",data=data)