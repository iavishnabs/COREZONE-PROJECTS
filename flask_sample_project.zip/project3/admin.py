# admin functions
from flask import *
from database import *

import smtplib
from email.mime.text import MIMEText
# from flask_mail import *

admin = Blueprint("admin",__name__)

@admin.route('/admin_home')
def admin_home():
	return render_template("admin_pages/admin_home.html")

@admin.route('/viewcustomers')
def viewcustomers():
	data={}
	q= "select * from users"
	data['view']=select(q)
	return render_template("admin_pages/viewcustomers.html",data=data)

# manage categories
@admin.route('/managecategory',methods=['get','post'])
def managecategory():
	data = {}
	# actions
	if "action" in request.args:
		action = request.args['action']
		cid = request.args['cid']
	else:
		action = None

    # delete
	if action == "delete":
		delq = "delete from category where cid='%s'"%(cid)
		delete(delq)
		return redirect(url_for("admin.managecategory"))

	if action == "update":
		q = "select * from category where cid='%s'"%(cid)
		res = select(q)
		data['updates'] = res

	# add
	if "add" in request.form:
		cname = request.form['cname']
		q2 = "insert into `category` values(null,'%s')"%(cname)
		insert(q2)
		return redirect(url_for("admin.managecategory"))
	# update

	if "update" in request.form:
		cname = request.form['cname']
		q3 = "update `category` set `cname`='%s' where cid='%s'"%(cname,cid)
		res = update(q3)
		return redirect(url_for("admin.managecategory"))

	
	q1 = "select * from `category`"
	data['view'] = select(q1)

	return render_template('admin_pages/managecategory.html',data=data) 


@admin.route("/managevendors",methods=['get','post'])
def managevendors():
	# fetch data in table
	data = {}
	q1 = "select * from vendor"
	data['viewV']=select(q1)

	# action define

	if "action" in request.args:
		action = request.args['action']
		vid = request.args['vid'] 
	else:
		action = None

	# action delete
	if action == "delete":
		q2 = "delete from `vendor` where `vid` ='%s'"%(vid)
		delete(q2)
		return redirect(url_for("admin.managevendors"))

	# action update
	if action == "update":
		q3 = "select * from `vendor` where `vid`='%s'"%(vid)
		res = select(q3)
		data['updates'] = res
		

	if "add" in request.form:
		comp = request.form['comp']
		details = request.form['details']
		est_year = request.form['est_year']
		q4  ="insert into vendor values(null,'%s','%s','%s')"%(comp,details,est_year)
		insert(q4)
		return redirect(url_for("admin.managevendors"))

	if 'update' in request.form:
		comp = request.form['comp']
		details = request.form['details']
		est_year = request.form['est_year']

		q5  = "update `vendor` set `company_name`='%s',`details`='%s',`estimated_year`='%s' where `vid` = '%s' "%(comp,details,est_year,vid)
		update(q5)
		return redirect(url_for("admin.managevendors"))
	return render_template("admin_pages/managevendors.html",data=data) 


@admin.route("/adminmanage_delvboy",methods=['get','post'])
def adminmanage_delvboy():
	data = {}
	if 'add' in request.form:
		fname = request.form['fname']
		lname = request.form['lname']
		uname = request.form['uname']
		pasw = request.form['pasw']
		email = request.form['email']
		phone = request.form['phone']
		adr = request.form['adr']
		dist = request.form['dist']
		pincode = request.form['pincode']

		q1 = "insert into `login` values(null,'%s','%s','deliveryboy')"%(uname,pasw)
		res = insert(q1)
		addq = "insert into `delivery_boys` values(null,'%s','%s','%s','%s','%s','%s','%s','%s')"%(res,fname,lname,adr,phone,pincode,dist,email)
		insert(addq)
		return redirect(url_for("admin.adminmanage_delvboy"))

	# action defines
	if "action" in request.args:
		action = request.args['action']
		boy_id = request.args['boy_id']
	else:
		action = None

	if action == "delete":
		delq = "delete from delivery_boys where boy_id='%s'"%(boy_id)
		delete(delq)
		return redirect(url_for("admin.adminmanage_delvboy"))
	if action == "update":
		upq = "select * from delivery_boys inner join login using (Login_id) where boy_id='%s'"%(boy_id)
		res = select(upq)
		data['updates'] = res

	if 'update' in request.form:
		
		fname = request.form['fname']
		lname = request.form['lname']
		uname = request.form['uname']
		pasw = request.form['pasw']
		email = request.form['email']
		phone = request.form['phone']
		adr = request.form['adr']
		dist = request.form['dist']
		pincode = request.form['pincode']

		q2 = "update delivery_boys set firstname='%s',lastname='%s',housename='%s',phone='%s',pincode='%s',place='%s',email='%s' where boy_id='%s'"%(fname,lname,adr,phone,pincode,dist,email,boy_id)
		update(q2)

		return redirect(url_for("admin.adminmanage_delvboy"))

    # fetch data
	q3 = "select * from delivery_boys"
	data['view']=select(q3)

	return render_template("admin_pages/adminmanage_delvboy.html",data=data) 

@admin.route("/adminmanage_shop",methods=['get','post'])
def adminmanage_shop():
	data = {}
	q = "select * from shop"
	data['view']=select(q)

	if "action" in request.args:
		action = request.args['action']
		shop_id = request.args['shop_id']

	else:
		action = None

	if action == "accept":   # notification has to besend
		q1 = "update shop set status='Approved' where shop_id='%s'"%(shop_id)
		update(q1)

		q4 = "select * from shop where shop_id='%s'"%(shop_id)
		data['email'] = select(q4) 
		res = data['email'] 
		if res:
			abc = res[0]['email']	
			email=abc

			try:
				gmail = smtplib.SMTP('smtp.gmail.com', 587)
				gmail.ehlo()
				gmail.starttls()
				gmail.login('encycodepediayt@gmail.com','lizxhqfbstwyvjua')

				ms = "Your Shop Registration is Approved Successfully. Thank you"
				msg = MIMEText(ms)

				msg['Subject'] = 'SHOP REGISTRATION STATUS'

				msg['To'] = email

				msg['From'] = 'encycodepediayt@gmail.com'
				gmail.send_message(msg)

				print("EMAIL SEND SUCCESFULLY")
				return redirect(url_for("admin.admin_home"))
			except Exception as e:
			    print("Couldn't setup email!!"+str(e))
			    return redirect(url_for("admin.adminmanage_shop"))
	if action == "reject":
		q1 = "update shop set status='Rejected' where shop_id='%s'"%(shop_id)
		update(q1)
		return redirect(url_for("admin.adminmanage_shop"))

		q4 = "select * from shop where shop_id='%s'"%(shop_id)
		data['email'] = select(q4) 
		res = data['email'] 
		if res:
			abc = res[0]['email']	
			email=abc

			try:
				gmail = smtplib.SMTP('smtp.gmail.com', 587)
				gmail.ehlo()
				gmail.starttls()
				gmail.login('encycodepediayt@gmail.com','lizxhqfbstwyvjua')

				ms = "SORRY, Your Shop Registration is Rejected. Try again"
				msg = MIMEText(ms)

				msg['Subject'] = 'SHOP REGISTRATION STATUS'

				msg['To'] = email

				msg['From'] = 'encycodepediayt@gmail.com'
				gmail.send_message(msg)

				print("EMAIL SEND SUCCESFULLY")
				return redirect(url_for("admin.admin_home"))

			except Exception as e:
			    print("Couldn't setup email!!"+str(e))
			    return redirect(url_for("admin.adminmanage_shop"))

	return render_template("admin_pages/adminmanage_shop.html",data=data)

@admin.route('/adminviewproduct')
def adminviewproduct():
	data = {}
	q = "select * from products inner join shop using(shop_id) inner join vendor using(vid)"
	data['view']=select(q)
	return render_template("admin_pages/adminviewproduct.html",data=data)

@admin.route('/adminviewstock')
def adminviewstock():
	data = {}
	q = "select * from stocks inner join products using(pid)"
	data['view'] = select(q)
	return render_template("admin_pages/adminviewstock.html",data=data)

@admin.route('/adminmanagecomplaint')
def adminmanagecomplaint():
	return render_template("admin_pages/adminmanagecomplaint.html")

#---------------------------trial email send notification
@admin.route("/mytry")
def mytry():
	try:
			gmail = smtplib.SMTP('smtp.gmail.com', 587)
			gmail.ehlo()
			gmail.starttls()
			gmail.login('encycodepediayt@gmail.com','lizxhqfbstwyvjua')
	
			print("hi")
			msg = MIMEText("vjhjjgjhgj")

			msg['Subject'] = 'Your Username and password is:'

			msg['To'] = "avishnabsofficial@gmail.com"

			msg['From'] = 'encycodepediayt@gmail.com'

		
			gmail.send_message(msg)

			print("EMAIL SEND SUCCESFULLY")

		
	except Exception as e:
		print("Couldn't setup email!!"+str(e))
	return "ok"