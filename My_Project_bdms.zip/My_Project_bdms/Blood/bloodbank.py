from flask import *
from database import *
import uuid


bloodbank = Blueprint('bloodbank',__name__) 

@bloodbank.route('/bloodbank_home')
def bloodbank_home():
	data={}
	qs="select * from blood_banks where bank_id='%s'"%(session['b_id'])
	data['bid']=select(qs)
	return render_template('blood_bank/bloodbank_home.html',data=data)

@bloodbank.route('/bloodbank_addnewuser',methods=['get','post'])
def bloodbank_addnewuser():
	data={}
	bid = session['b_id']

	grp = "select * from blood_group"
	data['groups'] =  select(grp)

	if "addnew" in request.form:
		name =  request.form['name']
		username =  request.form['username']
		password =  request.form['password']
		phone =  request.form['phone']
		email =  request.form['email']
		place =  request.form['place']
		post =  request.form['post']
		pin =  request.form['pin']
		city =  request.form['city']
		dist =  request.form['dist']
		grp = request.form['grp']
		image = request.files['image']
		isdonor = "donor" if 'isdonor' in  request.form else "reciever"

		q = "SELECT username FROM login WHERE username='%s'"%(username)
		res = select (q)
		if res:
			print("user already exist with this username")
			return "<script>alert('User already exists with this username and password');window.location.href='bloodbank_addnewuser';</script>"
		else:
			q = "insert into `login` values(null,'%s','%s','%s')"%(username,password,isdonor)
			res= insert(q)

			if isdonor == "donor":
				path= 'static/images/donor/'+ str(uuid.uuid4())+ image.filename
				image.save(path)
				q2 = "insert into `users` values(null,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(res,grp,path,name,phone,email,place,post,pin,city,dist,isdonor)
				insert(q2)
				return redirect(url_for('bloodbank.bloodbank_addnewuser'))
			else:
				path = 'static/images/reciever/'+ str(uuid.uuid4())+ image.filename
				q2 = "insert into `users` values(null,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(res,grp,path,name,phone,email,place,post,pin,city,dist,isdonor)
				insert(q2)
				return redirect(url_for('bloodbank.bloodbank_addnewuser'))

	return render_template('blood_bank/bloodbank_addnewuser.html',data=data)

@bloodbank.route('/bloodbank_viewbloodreq',methods=['get','post'])
def bloodbank_viewbloodreq():
	bid = session['b_id']
	data={}
	if "search" in request.form:
		reqst = request.form['reqst']
		print(reqst)
		if reqst == "hospital":
			q1 = "SELECT hospital_id,from_id,to_id,group_id,request_id,hospital_name,phone,email,place,district,pin,reference,`date`,description FROM blood_request INNER JOIN hospitals ON(`hospitals`.hospital_id=`blood_request`.from_id) WHERE `type` = 'hospital' AND to_id='%s' AND `blood_request`.`status`='pending'"%(bid)
			data['hospital']=select(q1)

			if "action" in request.args:
				action = request.args['action']
				request_id = request.args['request_id']
				group_id = request.args['group_id']
				from_id =  request.args['from_id']
				
				if action == "accept":
					q1 = "UPDATE `blood_request` SET `status`='Approved' WHERE request_id='%s'"%(request_id)
					update(q1)
					q2  = "INSERT INTO `transfusion_records` VALUES(null,'%s','%s','%s','1','donating','','self','')"%(group_id,bid,from_id)
					insert(q2)
					return redirect(url_for('bloodbank.bloodbank_viewbloodreq'))
				if action == "reject":
					q1 = "UPDATE `blood_request` SET `status`='Rejected' WHERE request_id='%s'"%(request_id)
					update(q1)
					return redirect(url_for('bloodbank.bloodbank_viewbloodreq'))
				if action == "chat":
					pass
				
		elif reqst == "reciever":
			q1 = "SELECT * FROM blood_request INNER JOIN users ON(`users`.user_id=`blood_request`.from_id) INNER JOIN hospitals ON(hospitals.hospital_id=blood_request.reference) WHERE `type` = 'reciever' AND to_id='%s' AND blood_request.`status`='pending'"%(bid)
			data['users']=select(q1)

			if "action" in request.args:
				action = request.args['action']
				request_id = request.args['request_id']
				group_id = request.args['group_id']
				from_id =  request.args['from_id']

				if action == "accept":
					q1 = "UPDATE `blood_request` SET `status`='Approved' WHERE request_id='%s'"%(request_id)
					update(q1)
					q2  = "INSERT INTO `transfusion_records` VALUES(null,'%s','%s','%s','1','donating','','self','')"%(group_id,bid,from_id)
					insert(q2)
					return redirect(url_for('bloodbank.bloodbank_viewbloodreq'))
					
				if action == "reject":
					q1 = "UPDATE `blood_request` SET `status`='Rejected' WHERE request_id='%s'"%(request_id)
					update(q1)
					return redirect(url_for('bloodbank.bloodbank_viewbloodreq'))

	return render_template('blood_bank/bloodbank_viewbloodreq.html',data=data)



@bloodbank.route('/chatwithhospital',methods=['get','post'])
def chatwithhospital():
	data={}
	from_id=session['lid']
	data['from_id']=from_id
	to_id=request.args['hospital_id']
	
	q1="select * from chat where  (from_id='%s' and to_id='%s') or (from_id='%s' and to_id='%s') "%(from_id,to_id,to_id,from_id)
	res  = select(q1)
	data['view']=res
	
	if 'submit' in request.form:
		msg=request.form['msg']
		q="insert into chat values(NULL,'%s','%s',now(),'%s')"%(from_id,to_id,msg)
		res=insert(q)
		return redirect(url_for('bloodbank.chatwithhospital', hospital_id=to_id))
	
	return render_template('blood_bank/chatwithhospital.html',data=data)


@bloodbank.route('/bloodbank_viewstockreport',methods=['get','post'])
def bloodbank_viewstockreport():
	bid = session['b_id']
	data= {}
	q = "select * from `bank_stock` inner join `blood_group` using(group_id) inner join `blood_banks` using(bank_id) where `bank_id` = '%s'"%(bid)
	data['view'] = select(q)

	q2 = "select * from blood_group"
	data['group'] = select(q2)

	if "add" in request.form:
		grp = request.form['grp']
		units = request.form['units']

		q = "insert into bank_stock values(null,'%s','%s','%s')"%(grp,bid,units)
		insert(q)
		return redirect(url_for('bloodbank.bloodbank_viewstockreport'))
	
	if "action" in request.args:
		action = request.args['action']
		stock_id = request.args['stock_id']
		if action == "update":
			q = "SELECT * FROM `bank_stock` INNER JOIN `blood_group` USING(group_id) INNER JOIN `blood_banks` USING(bank_id) WHERE stock_id = '%s'"%(stock_id)
			data['updates'] = select(q)
		
		if "update" in request.form:
			grp = request.form['grp']
			units = request.form['units']
			q = "update bank_stock set group_id='%s',units='%s' where stock_id='%s'"%(grp,units,stock_id)
			update(q)
			return redirect(url_for('bloodbank.bloodbank_viewstockreport'))
		

		if action == "delete":
			q = "delete from bank_stock where stock_id = '%s'"%(stock_id)
			delete(q)
			return redirect(url_for('bloodbank.bloodbank_viewstockreport'))
	return render_template('blood_bank/bloodbank_viewstockreport.html',data=data)


@bloodbank.route('/bloodbank_viewdonor',methods=['get','post'])
def bloodbank_viewdonor():
	data={}
	bid = session['b_id']
	q = "select * from users inner join blood_group using(group_id) where isdonor='donor'"
	data['view']=select(q)
	if "action" in request.args:
		action = request.args['action']
		user_id = request.args['user_id']
		group_id = request.args['group_id']

		if action == "send":
			data['updation'] = True 
		
	if "send" in request.form:
		desc = request.form['desc']
		dates = request.form['dates']
		q = "insert into blood_request values(null,'%s','%s','bloodbank','%s',curdate(),'%s','pending','%s','%s')"%(bid,user_id,bid,desc,group_id,dates)
		insert(q)
		return redirect(url_for('bloodbank.bloodbank_viewdonor'))
	
	if "actionn" in request.args:
		action = request.args['action']
		if action == "viewrequests":
			return redirect(url_for('bloodbank.bloodbank_viewrsendequests'))
	return render_template('blood_bank/bloodbank_viewdonor.html',data=data)


# donor records
@bloodbank.route('/bloodbank_viewrsendequests',methods=['get','post'])
def bloodbank_viewrsendequests():
	data = {}
	bid = session['b_id']
	q = "SELECT collection_date,user_id,`transfusion_records`.group_id,record_id,group_name,users.name AS user_name,users.email AS user_email,users.phone AS user_phone,users.city AS user_city,users.district AS user_district,users.pin AS user_pin,users.post AS user_post,`blood_request`.status AS st FROM `transfusion_records` INNER JOIN blood_request ON(`transfusion_records`.bank_id=blood_request.from_id) INNER JOIN blood_banks ON(blood_banks.bank_id=blood_request.from_id) INNER JOIN users ON(users.user_id=blood_request.to_id) INNER JOIN blood_group ON(blood_group.group_id=`blood_request`.group_id) WHERE blood_banks.bank_id='%s' AND blood_request.`type`='bloodbank' AND location='self' AND `transfusion_records`.`type`='recieving'"%(bid)
	data['view']=select(q)

	if "action" in request.args:
		action = request.args['action']
		group_id = request.args['group_id']
		user_id = request.args['user_id']
		record_id = request.args['record_id']
	else:
		action = None

	if action == "updatereq":
		q = "SELECT * FROM `transfusion_records` INNER JOIN users ON(users.user_id=transfusion_records.other_party_id) WHERE bank_id='%s' AND user_id='%s'"%(bid,user_id)
		data['updates'] = select(q)

		defl = data['updates']
		d = defl[0]['units']
		df = int(d) # default 0
		print('...........')
		# print('default value////',df)
		print('...........')

		st = "Select * from bank_stock where bank_id='%s' and group_id='%s'"%(bid,group_id)
		d = select(st)
		if d:
			dat = d[0]['units']
			res = int(dat)

			if "save" in request.form:
				units = request.form['units']
				dates = request.form['dates']
				

				a = units
				us = int(a)
				print('''''')
				print(us,'users;;;;')
			
				if us <=0:
					return "<script>alert('unit must be atleast one');window.location.href='bloodbank_viewrsendequests';</script>"
				elif us > df:
					df+=us
				elif us < df:
					df-=us
				else:
					df
				q = "update transfusion_records set units='%s',collection_date='%s' where record_id='%s'"%(df,dates,record_id)
				update(q)

				q2 = "select `type` from transfusion_records where record_id='%s'"%(record_id)
				ress = select(q2)
				types = ress[0]['type'] 

				if us == 1:
					st = "update bank_stock set units=units+1 where group_id='%s' and bank_id='%s'"%(group_id,bid)
					update(st)
					return redirect(url_for('bloodbank.bloodbank_viewrsendequests'))
				else:
					
					if types == 'recieving':
						st = "update bank_stock set units=units+df where group_id='%s' and bank_id='%s'"%(group_id,bid)
						update(st)
						return redirect(url_for('bloodbank.bloodbank_viewrsendequests'))

				return redirect(url_for('bloodbank.bloodbank_viewrsendequests'))
				

	return render_template('blood_bank/bloodbank_viewrsendequests.html',data=data)

@bloodbank.route('/bloodbank_coordinationreqst')
def bloodbank_coordinationreqst():
	data={}
	bid = session['b_id']
	q = "SELECT venue,camp_date,camp_id,`name`,email,phone,camp_date,bank_id,cord_req_id,org_id FROM `camp_cordination_request` INNER JOIN camp USING(cord_req_id) INNER JOIN organisations USING(org_id) WHERE camp_cordination_request.`status`='pending' AND bank_id ='%s'"%(bid)
	data['view']=select(q)

	if "action" in request.args:
		action = request.args['action']
		cord_req_id = request.args['cord_req_id']
		camp_id = request.args['camp_id']
		org_id = request.args['org_id']
		camp_date = request.args['camp_date']
		venue = request.args['venue']

		if action == "accept":
			q2 = "UPDATE `camp_cordination_request` SET `status`='accepted' WHERE cord_req_id='%s'"%(cord_req_id)
			update(q2)

			s = "SELECT * FROM `donation_willingness` INNER JOIN users ON(users.user_id=donation_willingness.donor_id) INNER JOIN camp USING(camp_id) INNER JOIN `camp_cordination_request` USING(cord_req_id) WHERE camp_id='%s' AND cord_req_id='%s' and bank_id='%s'"%(camp_id,cord_req_id,bid)

			res = select(s)
			if res:
				grp = res[0]['group_id']
				donr = res[0]['donor_id']

			q3 = "insert into transfusion_records values(null,'%s','%s','%s','1','recieving','%s','%s','%s')"%(grp,bid,donr,camp_date,venue,camp_id)
			insert(q3)

			return redirect(url_for('bloodbank.bloodbank_coordinationreqst'))
	return render_template('blood_bank/bloodbank_coordinationreqst.html',data=data)

@bloodbank.route('/bloodbank_viewcamp')
def bloodbank_viewcamp():
	data={}
	if "action" in request.args:
		action = request.args['action']
		camp_id = request.args['camp_id']

		if action == "view":
			q = "SELECT * FROM camp WHERE camp_id='%s'"%(camp_id)
			data['viewcamp']=select(q)

	return render_template('blood_bank/bloodbank_viewcamp.html',data=data)

@bloodbank.route('/bloodbank_chatwithhospital')
def bloodbank_chatwithhospital():
	return render_template('blood_bank/bloodbank_chatwithhospital.html')

@bloodbank.route('/bloodbank_updaterequest',methods=['get','post'])
def bloodbank_updaterequest():
	data={}
	if "action" in request.args:
		action = request.args['action']
		request_id = request.args['request_id']

		if action == "update":
			q = "SELECT request_id FROM blood_request WHERE request_id='%s'"%(request_id)
			data['req'] =  select(q)

	if "save" in request.form:
		desc = request.form['desc']
		q = "update blood_request set description='%s' where request_id='%s'"%(desc,request_id)
		update(q)
		return redirect(url_for('bloodbank.bloodbank_viewbloodreq'))
	
	return render_template('blood_bank/bloodbank_updaterequest.html',data=data)

# camp record
@bloodbank.route('/bloodbank_updatecamprecords',methods=['get','post'])
def bloodbank_updatecamprecords():
	data={}
	bid = session['b_id']
	gp = "select * from blood_group inner join bank_stock using(group_id) where bank_id='%s'"%(bid)
	data['groups'] = select(gp) 

	if "action" in request.args:
		action = request.args['action']
		record_id = request.args['record_id']
		group_id = request.args['group_id']
	else:
		action = None

	if action == "update":
		q = "select * from transfusion_records where record_id='%s'"%(record_id)
		data['updates']= select(q)

		default = data['updates']
		d = default[0]['units']
		df = int(d) # default 0
		print('...........')
		print('default value////',df)
		print('...........')

		st = "Select * from bank_stock where bank_id='%s' and group_id='%s'"%(bid,group_id)
		d = select(st)
		if d:
			dat = d[0]['units']
			res = int(dat)

			if "save" in request.form:
				units = request.form['units']
				dates = request.form['dates']

				a = units
				us = int(a)
				print('''''')
				print(us,'users;;;;')
			
				if us<=res:
					if us <=0:
						return "<script>alert('unit must be atleast one');window.location.href='bloodbank_updatecamprecords';</script>"
					elif us > df:
						df+=us
					elif us < df:
						df-=us
					else:
						df
					
					q = "update transfusion_records set units='%s', collection_date='%s' where record_id='%s'"%(df,dates,record_id)
					update(q)

					q2 = "select `type` from transfusion_records where record_id='%s'"%(record_id)
					ress = select(q2)
					types = ress[0]['type'] 

					if us == 1:
						st = "update bank_stock set units=units+1 where group_id='%s' and bank_id='%s'"%(group_id,bid)
						update(st)
						return redirect(url_for('bloodbank.bloodbank_hospitalrecord'))
					else:
					
						if types == 'recieving':
							st = "update bank_stock set units=units+'%s' where group_id='%s' and bank_id='%s'"%(df,group_id,bid)
							update(st)
							return redirect(url_for('bloodbank.bloodbank_updatecamprecords'))
				else:
					return "<script>alert('not enough stock');window.location.href='bloodbank_updatecamprecords';</script>"
	
	q = "SELECT transfusion_records.group_id,group_name,record_id,bank_name,users.name AS user_name,location,units,collection_date FROM `transfusion_records` INNER JOIN blood_banks USING(bank_id) inner join blood_group on(blood_group.group_id=transfusion_records.group_id) INNER JOIN camp USING(camp_id) INNER JOIN users ON(users.user_id=transfusion_records.other_party_id) WHERE camp_id !='' AND bank_id='%s'"%(bid)
	data['view']=select(q)
	
	return render_template('blood_bank/bloodbank_updatecamprecords.html',data=data)



# hospital report
@bloodbank.route('/bloodbank_hospitalrecord',methods=['get','post'])
def bloodbank_hospitalrecord():
	data = {}
	q = "SELECT * FROM `transfusion_records` WHERE `type`='donating'"
	data['view'] = select(q)

	bid = session['b_id']
	
	q1 = " SELECT * FROM transfusion_records INNER JOIN blood_request ON(transfusion_records.other_party_id=blood_request.from_id) INNER JOIN hospitals ON(hospitals.hospital_id=blood_request.from_id) INNER JOIN blood_group ON(blood_group.group_id=transfusion_records.group_id) WHERE blood_request.`type`='hospital' AND transfusion_records.`type`='donating' AND bank_id='%s'"%(bid)
	data['hospital']=select(q1)

	if "action" in request.args:
		action = request.args['action']
		record_id = request.args['record_id']
		group_id = request.args['group_id']
		
	else:
		action = None
		
	if action == "update":
		q = "SELECT * FROM transfusion_records WHERE record_id='%s'"%(record_id)
		data['updates'] = select(q)

		default = data['updates']
		d = default[0]['units']
		df = int(d) # default 0
		print('...........')
		print('default value////',df)
		print('...........')

		st = "Select * from bank_stock where bank_id='%s' and group_id='%s'"%(bid,group_id)
		d = select(st)
		if d:
			dat = d[0]['units']
			res = int(dat)
	
			if "save" in request.form:
				dates = request.form['dates']
				units  = request.form['units'] # user input

				a = units
				us = int(a)
			
				if us<=res:
					if us <=0:
						return "<script>alert('unit must be atleast one');window.location.href='bloodbank_hospitalrecord';</script>"
					elif us > df:
						df+=us
					elif us < df:
						df-=us
					else:
						df
					
					q2 = "update transfusion_records set units='%s',collection_date='%s' where record_id='%s'"%(df,dates,record_id)
					update(q2)
					q2 = "select `type` from transfusion_records where record_id='%s'"%(record_id)
					ress = select(q2)
					types = ress[0]['type'] 

					if us == 1:
						st = "update bank_stock set units=units-1 where group_id='%s' and bank_id='%s'"%(group_id,bid)
						update(st)
						return redirect(url_for('bloodbank.bloodbank_hospitalrecord'))
					else:

						if types == 'donating':
							st = "update bank_stock set units=units-'%s' where group_id='%s' and bank_id='%s'"%(df,group_id,bid)
							update(st)
							return redirect(url_for('bloodbank.bloodbank_hospitalrecord'))
					return redirect(url_for('bloodbank.bloodbank_hospitalrecord'))
				else:
					return "<script>alert('not enough stock');window.location.href='bloodbank_hospitalrecord';</script>"
	return render_template('blood_bank/bloodbank_hospitalrecord.html',data=data)


# recievers report
@bloodbank.route('/bloodbank_recieversrecord',methods=['get','post'])
def bloodbank_recieversrecord():
	data = {}
	q = "SELECT * FROM `transfusion_records` WHERE `type`='donating'"
	data['view'] = select(q)
	bid = session['b_id']

	q1 = "SELECT * FROM `transfusion_records` INNER JOIN users ON(users.user_id=transfusion_records.`other_party_id`) INNER JOIN blood_request ON(blood_request.from_id=`transfusion_records`.`other_party_id`) WHERE `transfusion_records`.`type`='donating' AND isdonor='reciever' AND  `blood_request`.`status`='Approved' AND bank_id='%s'"%(bid)
	data['users']=select(q1)

	if "action" in request.args:
		action = request.args['action']
		record_id = request.args['record_id']
		group_id = request.args['group_id']
	else:
		action = None
		
	if action == "update":
		q = "SELECT * FROM transfusion_records WHERE record_id='%s'"%(record_id)
		data['updates'] = select(q)

		default = data['updates']
		d = default[0]['units']
		df = int(d) # default 0
		print('...........')
		print('default value////',df)
		print('...........')

		st = "Select * from bank_stock where bank_id='%s' and group_id='%s'"%(bid,group_id)
		d = select(st)
		if d:
			dat = d[0]['units']
			res = int(dat)
	
			if "save" in request.form:
				dates = request.form['dates']
				units  = request.form['units'] # user input

				a = units
				us = int(a)
			
				if us<=res:
					if us <=0:
						return "<script>alert('unit must be atleast one');window.location.href='bloodbank_recieversrecord';</script>"
					elif us > df:
						df+=us
					elif us < df:
						df-=us
					else:
						df
					q2 = "update transfusion_records set units='%s',collection_date='%s' where record_id='%s'"%(df,dates,record_id)
					update(q2)
					q2 = "select `type` from transfusion_records where record_id='%s'"%(record_id)
					ress = select(q2)
					types = ress[0]['type'] 

					if us == 1:
						st = "update bank_stock set units=units-1 where group_id='%s' and bank_id='%s'"%(group_id,bid)
						update(st)
						return redirect(url_for('bloodbank.bloodbank_recieversrecord'))
					else:
						if types == 'donating':
							st = "update bank_stock set units=units-'%s' where group_id='%s' and bank_id='%s'"%(df,group_id,bid)
							update(st)
							return redirect(url_for('bloodbank.bloodbank_recieversrecord'))
					
					return redirect(url_for('bloodbank.bloodbank_recieversrecord'))	
				else:
					return "<script>alert('not enough stock');window.location.href='bloodbank_recieversrecord';</script>"
	return render_template('blood_bank/bloodbank_recieversrecord.html',data=data)
