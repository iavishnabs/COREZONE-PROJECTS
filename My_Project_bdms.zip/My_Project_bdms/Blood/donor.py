from flask import *
from database import *

donor = Blueprint('donor',__name__)


@donor.route('/donor_home')
def donor_home():
    data={}
    qs="select * from users where user_id='%s'"%(session['d_id'])
    data['dnr']=select(qs)
    
    return render_template("donor/donor_home.html",data=data)



@donor.route('/donor_view_camp', methods=['get','post'])
def donor_view_camp():
    did = session['d_id']
    data={}
    q1="SELECT camp_cordination_request.*, camp.* FROM camp_cordination_request INNER JOIN camp ON camp_cordination_request.cord_req_id = camp.cord_req_id"
    data['view_camp'] = select(q1)

    if "action" in request.args:
        action = request.args['action']
        camp_id = request.args['camp_id']
        group_id = request.args['group_id']
        bank_id = request.args['bank_id']
      
        if action == "willing":
            q = "insert into donation_willingness values(null,'%s','%s',curdate() )"%(camp_id,did)
            insert(q)
            return redirect(url_for('donor.donor_view_camp'))

    return render_template("donor/donor_view_camp.html",data = data)

@donor.route('/donor_view_organisation')
def donor_view_organisation():
    data={}
    q2 = "select * from organisations"
    data['view_org'] = select(q2)

    return render_template("donor/donor_view_organisation.html",data=data)

@donor.route('/donor_request_from_blood_bank')
def donor_request_from_blood_bank():
    did = session['d_id']
    data={}
    q3="SELECT *,blood_request.`status` AS st FROM blood_request INNER JOIN users ON(users.user_id=blood_request.to_id) INNER JOIN blood_banks ON(blood_banks.bank_id=blood_request.from_id) WHERE user_id='%s' and blood_request.`status`='pending'"%(did)
    data['view_blood']= select(q3)
    
    if "action" in request.args:
        action = request.args['action']
        request_id = request.args['request_id']
        group_id =request.args['group_id']
        bank_id = request.args['bank_id']

        if action == "confirm":
            up="UPDATE blood_request SET `status` = 'Approved' WHERE request_id='%s'"%(request_id)
            update(up)
            q2 = "insert into transfusion_records values(null,'%s','%s','%s','1','recieving','','self','')"%(group_id,bank_id,did)
            insert(q2)
            return redirect(url_for('donor.donor_request_from_blood_bank')) 
    return render_template("donor/donor_request_from_blood_bank.html",data=data)


@donor.route('/donor_view_donated_details')
def donor_view_donated_details():
    did = session['d_id']
    data={}
    q = "SELECT *,users.image as img,users.place as pls,users.email as em,users.phone as phn FROM `transfusion_records` INNER JOIN users ON(users.user_id=transfusion_records.`other_party_id`) INNER JOIN blood_group ON(transfusion_records.group_id=blood_group.group_id) INNER JOIN blood_banks USING(bank_id) WHERE user_id='%s'"%(did)
    data['view_don'] = select(q)
    return render_template("donor/donor_view_donated_details.html",data=data)
    


