from flask import *
from public import public
from admin import admin
from hospital import hospital
from recievers import recievers
from bloodbank import bloodbank
from donor import donor
from organisation import *

app = Flask(__name__)

app.secret_key = "blaaah"

app.register_blueprint(public)
app.register_blueprint(admin)
app.register_blueprint(hospital)
app.register_blueprint(recievers)
app.register_blueprint(bloodbank)
app.register_blueprint(donor)
app.register_blueprint(organisation) 

app.run(debug=True,port="5004")