from flask import *
from database import *

hospital = Blueprint('hospital',__name__)

@hospital.route('/hospital_home')
def hospital_home():
    data={}
    qs="select * from hospitals where hospital_id='%s'"%(session['h_id'])
    data['hsp']=select(qs)
    
    return render_template("hospital/hospital_home.html",data=data)

@hospital.route('/hospital_view_blood_bank')
def hospital_view_blood_bank():

    hid=session['h_id']

    data={}
    
    q2 ="SELECT * FROM blood_banks"
    data['view1'] = select(q2)

   

    if "action" in request.args:
        action = request.args['action']
        bank_id= request.args['bank_id']
        group_id = request.args['group_id']

        if action == "accept":
            q1 = "insert into blood_request values(null,'%s','%s','hospital','%s',curdate(),' ','pending','%s')"%(hid,bank_id,hid,group_id)
            insert(q1)
            return redirect(url_for('hospital.hospital_view_blood_bank'))
    return render_template("hospital/hospital_view_blood_bank.html",data=data)

@hospital.route('/hospital_view_overall_requests')
def hospital_view_overall_requests():
    data={}
    q2 = "SELECT blood_request.*,blood_banks.*, blood_group.* FROM blood_request INNER JOIN blood_banks ON blood_request.to_id = blood_banks.bank_id INNER JOIN blood_group ON blood_request.group_id = blood_group.group_id WHERE blood_request.`status` = 'pending' AND `type`='hospital'"
    data['view2'] = select(q2)
    return render_template("hospital/hospital_view_overall_requests.html",data=data)


@hospital.route('/hospital_view_status')
def hospital_view_status():
    hid=session['h_id']
    data = {}
    if "action" in request.args:
        action = request.args['action']
        bank_id = request.args['bank_id']
        
        if action == "view":
            q3 = "SELECT *, blood_request.status FROM blood_request INNER JOIN blood_banks ON blood_request.to_id = blood_banks.bank_id INNER JOIN blood_group ON blood_request.group_id = blood_group.group_id WHERE from_id='%s' AND bank_id='%s'"%(hid,bank_id)
            data['view_status'] = select(q3)

    return render_template("hospital/hospital_view_status.html", data=data)


@hospital.route('/hospital_check_blood')
def hospital_check_blood():
    hid=session['h_id']
    data={}
    if "action" in request.args:
        action = request.args['action']
        bank_id= request.args['bank_id']
       

        if action == "check":
            q3 = "SELECT * FROM bank_stock inner join blood_group using(group_id) WHERE bank_id='%s'"%(bank_id)
            data['view2']=select(q3)

    if "actionn" in request.args:
        action = request.args['actionn']
        bank_id= request.args['bank_id']
        group_id = request.args['group_id']

        if action == "accept":
            q1 = "insert into blood_request values(null,'%s','%s','hospital','%s',curdate(),' ','pending','%s')"%(hid,bank_id,hid,group_id)
            insert(q1)
            return redirect(url_for('hospital.hospital_view_blood_bank'))

    return render_template("hospital/hospital_check_blood.html",data=data)


@hospital.route('/hospital_chat',methods=['get','post'])
def hospital_chat():
    data={}
    from_id=session['lid']
    data['from_id']=from_id
    to_id=request.args['bank_login_id']

    q1="select * from chat where  (from_id='%s' and to_id='%s') or (from_id='%s' and to_id='%s') "%(from_id,to_id,to_id,from_id)
    res=select(q1)
    data['view']=res
    

    if 'submit' in request.form:
        msg=request.form['msg']
        q="insert into chat values(NULL,'%s','%s',now(),'%s')"%(from_id,to_id,msg)
        res=insert(q)
        return redirect(url_for('hospital.hospital_chat', bank_login_id=to_id))
    return render_template("hospital/hospital_chat.html",data=data)




@hospital.route('/hospital_required_date', methods=['get','post'])
def hospital_required_date():
    hid=session['h_id'] 
    data={}
    if 'action' in request.args:
        action = request.args['action']
        bank_id = request.args['bank_id']
    if 'save' in request.form:
        required_date= request.form['required_date']

        if "actionn" in request.args:
            action = request.args['actionn']
            bank_id= request.args['bank_id']
            group_id = request.args['group_id']

        if action == "accept":
            q1 = "insert into blood_request values(null,'%s','%s','hospital','%s',curdate(),' ','pending','%s','%s')"%(hid,bank_id,hid,group_id,required_date)
            insert(q1)
            return redirect(url_for('hospital.hospital_view_blood_bank'))
      
    return render_template("hospital/hospital_required_date.html",data=data)





