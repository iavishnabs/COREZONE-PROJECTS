@hospital.route('/hospital_chat',methods=['get','post'])
def hospital_chat():
    data={}
    from_id=session['lid']
    data['from_id']=from_id

    to_id=request.args['bank_login_id']

    q1="select * from chat where  (from_id='%s' and to_id='%s') or (from_id='%s' and to_id='%s') "%(from_id,to_id,to_id,from_id)
    res=select(q1)
    data['view']=res
    

    if 'submit' in request.form:
        msg=request.form['msg']
        q="insert into chat values(NULL,'%s','%s',now(),'%s')"%(from_id,to_id,msg)
        res=insert(q)
        return redirect(url_for('hospital.hospital_chat', bank_login_id=to_id))
    return render_template("hospital/hospital_chat.html",data=data)
