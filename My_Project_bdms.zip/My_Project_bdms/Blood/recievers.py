from flask import *
from database import *

recievers = Blueprint('recievers',__name__) 

@recievers.route('/reciever_home')
def reciever_home():
   
    data={}
    qs="select * from users where user_id='%s'"%(session['r_id'])
    data['rcvr']=select(qs)
    return render_template('recievers/reciever_home.html',data=data)


@recievers.route('/reciever_viewbloodbank',methods=['get','post'])
def reciever_viewbloodbank():
    rid =session['r_id']
    data={}
    q = "SELECT * FROM `blood_banks` WHERE STATUS='Approved'"
    data['view']=select(q)

    q2 = "SELECT group_id FROM users WHERE user_id='%s'"%(rid)
    res=select(q2)
    group_id = res[0]['group_id']

    q3 = "SELECT * FROM hospitals"
    data['hospitals']=select(q3)

    if "action" in request.args:
        action = request.args['action']
        bank_id = request.args['bank_id'] 
        if action == "send":
            q = "select reference from blood_request"
            data['updates'] = select(q)
            
    if "save" in request.form:
        ref = request.form['ref']
        dates = request.form['dates']
    
        q = "insert into blood_request values(null,'%s','%s','reciever','%s',curdate(),'','pending','%s','%s')"%(rid,bank_id,ref,group_id,dates)
        insert(q)
        return redirect(url_for('recievers.reciever_viewbloodbank'))
    return render_template('recievers/reciever_viewbloodbank.html',data=data) 

@recievers.route('/reciever_viewbloodrequest')
def reciever_viewbloodrequest():
    data={}
    rid =session['r_id']
    q = "select *,blood_request.`status` AS st from blood_request inner join users on(users.user_id=blood_request.from_id) inner join blood_banks on(blood_banks.bank_id=blood_request.to_id) where user_id='%s'"%(rid)
    data['view'] =  select(q)

    if "action" in request.args:
        action  = request.args['action']
        request_id = request.args['request_id']
        if action == "reject":
            q = "update blood_request set `status`='Cancelled' where request_id='%s'"%(request_id)
            update(q)
            return redirect(url_for('recievers.reciever_viewbloodrequest')) 
        
    return render_template('recievers/reciever_viewbloodrequest.html',data=data) 