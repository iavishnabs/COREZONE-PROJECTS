from flask import *
from  database import*

organisation = Blueprint('organisation',__name__)


@organisation.route('/organisation_home')
def organisation_home():
    data={}
    qs="select * from organisations where org_id='%s'"%(session['o_id'])
    data['orgs']=select(qs)
    return render_template("organisation/organisation_home.html",data=data)


@organisation.route('/organisation_request')
def organisation_request():
    data={}
    q1 = "SELECT * FROM blood_banks"
    data['view'] = select(q1)

    return render_template("organisation/organisation_request.html",data=data)


@organisation.route('/organisation_status')
def organisation_status():
    data ={}
    if 'action' in request.args:
        action = request.args['action']
        bank_id=request.args['bank_id']

        if action == 'view':
            q = "SELECT * FROM blood_banks INNER JOIN `camp_cordination_request` USING(bank_id) WHERE bank_id='%s'"%(bank_id)
            data['view_status']=select(q) 

    return render_template("organisation/organisation_status.html",data=data)


@organisation.route('/organisation_manage_camp',methods=['get','post'])
def organisation_manage_camp():
    data={}
    
    if 'action' in request.args:
        action = request.args['action']
        camp_id = request.args['camp_id']
    else:
        action = None
    if action == 'update':
        up="select * from camp where camp_id='%s'"%(camp_id)
        data['updates'] = select(up)
    if 'update' in request.form:
        venue = request.form['venue']
        description = request.form['description']
        start_time = request.form['start_time']
        end_time = request.form['end_time']

        q5 = "update camp set venue='%s',description='%s',start_time='%s',end_time='%s' where camp_id = '%s'"%(venue,description,start_time,end_time,camp_id)
        update(q5)

        return redirect(url_for('organisation.organisation_manage_camp'))

    if 'add' in request.form:
        venue = request.form['venue']
        description = request.form['description']
        start_time = request.form['start_time']
        end_time = request.form['end_time']

        q6 = "insert into camp values(null,null,'%s','%s','%s','%s')"%(venue,start_time,end_time,description)
        insert(q6)
        
        return redirect(url_for('organisation.organisation_manage_camp'))
    

    if action == 'delete':
        d1 = "delete from camp where camp_id='%s'"%(camp_id)
        delete(d1)

        d2 ="delete camp, camp_cordination_request FROM camp INNER JOIN camp_cordination_request ON camp.cord_req_id = camp_cordination_request.cord_req_id WHERE camp.camp_id = '%s'"%(camp_id)
        delete(d2)

        return redirect(url_for('organisation.organisation_manage_camp'))


    q1 = "SELECT * FROM camp"
    data['view_manage'] = select(q1)


    
    return render_template("organisation/organisation_manage_camp.html",data=data)



@organisation.route('/organisation_view_donor')
def organisation_view_donor():
    data ={}
    q1 = "SELECT blood_group.*,users.*,donation_willingness.* FROM blood_group INNER JOIN users ON blood_group.group_id = users.group_id INNER JOIN donation_willingness ON users.user_id = donation_willingness.donor_id;"
    data['view_donor'] = select(q1)
    return render_template("organisation/organisation_view_donor.html",data=data)


@organisation.route('/organisation_view_report')
def organisation_view_report():
    data={}
    q6="SELECT * FROM transfusion_records INNER JOIN blood_group ON transfusion_records.group_id = blood_group.group_id INNER JOIN blood_banks ON transfusion_records.bank_id = blood_banks.bank_id INNER JOIN users ON transfusion_records.other_party_id = users.user_id INNER JOIN camp ON transfusion_records.camp_id = camp.camp_id INNER JOIN camp_cordination_request ON camp.cord_req_id = camp_cordination_request.cord_req_id"
    data['view_report'] = select(q6)

    q7 = "SELECT COUNT(record_id)  AS `count` FROM `transfusion_records` WHERE `type`='recieving'"
    i=select(q7)

    total_donors = i[0]['count'] if i else 0
    data['total_donors'] = total_donors

    q8 = "SELECT SUM(units)  AS `units` FROM `transfusion_records` WHERE `type`='recieving'"
    j=select(q8)

    sum_units = int(j[0]['units']) if j and j[0]['units'] is not None else 0
    data['sum_units'] = sum_units
    
    return render_template("organisation/organisation_view_report.html",data=data)




@organisation.route('/organisation_camp', methods=['get','post'])
def organisation_camp():
    orgs=session['o_id'] 
    data={}

    if 'action' in request.args:
        action = request.args['action']
        bank_id = request.args['bank_id']

    if 'send' in request.form:
        camp_date = request.form['camp_date']

        q1 = "insert into camp_cordination_request values(null,'%s','%s',curdate(),'%s','pending')"%(orgs,bank_id,camp_date)
        res = insert(q1)
        q = "update camp set cord_req_id='%s'"%(res)
        update(q)
        return redirect(url_for('organisation.organisation_request'))
    
    return render_template("organisation/organisation_camp.html")





