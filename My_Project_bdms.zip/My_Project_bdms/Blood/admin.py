from flask import *
from database import *

import smtplib
from email.mime.text import MIMEText

admin = Blueprint('admin',__name__) 

@admin.route('/admin_home')
def admin_home():
	return render_template('admin/admin_home.html')

@admin.route('/admin_managebloodgroup',methods=['get','post'])
def admin_managebloodgroup():
	data= {}
	q = "select * from blood_group"
	data['view'] = select(q) 

	if "action" in request.args:
		action = request.args['action']
		group_id = request.args['group_id']

		if action == "delete":   
			q = "delete from blood_group where group_id='%s'"%(group_id)
			delete(q)
			return redirect(url_for('admin.admin_managebloodgroup'))
		if action == "update":
			q = "select * from blood_group where group_id='%s'"%(group_id)
			data['updates'] = select(q)
	else:
		action = None

	if "add" in request.form:
		group = request.form['group']
		desc = request.form['desc']

		q = "insert into blood_group values(null,'%s','%s')"%(group,desc)
		insert(q)
		return redirect(url_for('admin.admin_managebloodgroup'))
	if "update" in request.form:
		group = request.form['group']
		desc = request.form['desc']

		q = "update blood_group set group_name='%s', description='%s' where group_id='%s'"%(group,desc,group_id)
		update(q)
		return redirect(url_for('admin.admin_managebloodgroup'))
	return render_template('admin/admin_managebloodgroup.html',data=data)


@admin.route('/admin_viewbloodbank')
def admin_viewbloodbank():
	data = {}
	q = "SELECT * FROM `blood_banks`"
	data['view'] = select(q)

	if "action" in request.args:
		action = request.args['action']
		bank_id = request.args['bank_id']

		if action == "approve":
			q = "update `blood_banks` set `status`='Approved' where `bank_id`='%s'"%(bank_id)
			update(q) 
			return redirect(url_for('admin.admin_viewbloodbank'))
		if action == "reject":
			q = "update `blood_banks` set `status`='Rejected' where `bank_id`='%s'"%(bank_id)
			update(q) 
			return redirect(url_for('admin.admin_viewbloodbank'))
	return render_template('admin/admin_viewbloodbank.html',data=data)

@admin.route('/admin_viewdonors')
def admin_viewdonors():
	data={}
	q = "SELECT * FROM `users` INNER JOIN `blood_group` USING(group_id) WHERE `isdonor`='donor'"
	data['view'] = select(q)
	return render_template('admin/admin_viewdonors.html',data=data)


@admin.route('/admin_viewhospital')
def admin_viewhospital(): 
	data = {}
	q= "select * from hospitals"
	data['view']=select(q)

	if "action" in request.args:
		action = request.args['action']
		hospital_id = request.args['hospital_id']

		if action == "approve":
			q = "update `hospitals` set `status`='Approved' where `hospital_id`='%s'"%(hospital_id)
			update(q) 
			return redirect(url_for('admin.admin_viewhospital'))
		if action == "reject":
			q = "update `hospitals` set `status`='Rejected' where `hospital_id`='%s'"%(hospital_id)
			update(q) 
			return redirect(url_for('admin.admin_viewhospital'))
	return render_template('admin/admin_viewhospital.html',data=data)

	
@admin.route('/admin_vieworganisation')
def admin_vieworganisation():
	data = {}
	q= "select * from organisations"
	data['view']=select(q)

	if "action" in request.args:
		action = request.args['action']
		org_id = request.args['org_id']

		if action == "approve":
			q = "update `organisations` set `status`='Approved' where `org_id`='%s'"%(org_id)
			update(q) 
			return redirect(url_for('admin.admin_vieworganisation'))
		if action == "reject":
			q = "update `organisations` set `status`='Rejected' where `org_id`='%s'"%(org_id)
			update(q) 
			return redirect(url_for('admin.admin_vieworganisation'))
	return render_template('admin/admin_vieworganisation.html',data=data)


@admin.route('/admin_viewrecievers')
def admin_viewrecievers():
	data={}
	q = "SELECT * FROM `users` INNER JOIN `blood_group` USING(group_id) WHERE `isdonor`='reciever'"
	data['view'] = select(q)
	return render_template('admin/admin_viewrecievers.html',data=data)

@admin.route('/admin_viewstockreport')
def admin_viewstockreport():
	data={}
	q = "SELECT group_name,bank_name,units FROM bank_stock INNER JOIN blood_banks USING(bank_id) INNER JOIN blood_group USING(group_id) WHERE `status`='Approved'"
	data['view'] = select(q)
	return render_template('admin/admin_viewstockreport.html',data=data)

