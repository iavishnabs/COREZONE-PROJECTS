from flask import *
from database import *
import uuid


public = Blueprint('public',__name__)

@public.route('/')
def index():
	qry="SELECT * FROM `blood_request` WHERE `required_date`<CURDATE() AND STATUS='pending'"
	res=select(qry)
	for i in res:
		qry1="update `blood_request` set `status`='invalid' where `request_id`='%s'"%(i["request_id"])
		update(qry1)
	return render_template('public/index.html')


@public.route('/login',methods=['get','post'])
def login():
	if "login" in request.form:
		username = request.form['username']
		password  =  request.form['password']

		q = "select * from `login` where `username`='%s' and `password`='%s'"%(username,password)
		res = select(q)
		if res:
			session['lid'] = res[0]['login_id']
			types = res[0]['usertype']
			if types=="donor":
				q = "select * from `users` where `login_id`='%s'"%(session['lid'])
				res = select(q)
				if res:
					session['d_id'] = res[0]['user_id']
					return """
							<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; padding: 20px; text-align: center; border-radius: 20px;">
								<img src="static/assets/img/login1.gif" alt="Login Successful" style="width: 300px; >
								<h3 style="color: red;"><b>Loading...</b></h3>
							</div>
							<script>
								setTimeout(function() {
									window.location.href = 'donor_home';
								}, 4000); // Redirect after 2 seconds
						   </script>
						"""            
				
			elif types=="reciever":
				q = "select * from `users` where `login_id`='%s'"%(session['lid'])
				res = select(q)
				if res:
					session['r_id'] = res[0]['user_id']
					# return redirect(url_for('recievers.reciever_home'))
					return """
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; padding: 20px; text-align: center; border-radius: 20px;">
        <img src="static/assets/img/login1.gif" alt="Login Successful" style="width: 300px; >
        <h3 style="color: red;"><b>Loading...</b></h3>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = 'reciever_home';
        }, 4000); // Redirect after 2 seconds
    </script>
"""

			elif types=="hospital":
				q = "select * from `hospitals` where `login_id`='%s' and `status`='Approved'"%(session['lid'])
				res = select(q)
				if res:
					session['h_id'] = res[0]['hospital_id']
					return """
							<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; padding: 20px; text-align: center; border-radius: 20px;">
								<img src="static/assets/img/login1.gif" alt="Login Successful" style="width: 300px; ">
								<h3 style="color: red;"><b>Login Successful.</b></h3>
								
							</div>
							<script>
								setTimeout(function() {
									window.location.href = 'hospital_home';
								}, 4000); // Redirect after 2 seconds
						   </script>
						"""
				else:
					return "<script>alert('Your Account status is pending');window.location.href='login'</script>"
	
			elif types=="orgs":
				q = "select * from `organisations` where `login_id`='%s' and `status`='Approved'"%(session['lid'])
				res = select(q)
				if res:
					session['o_id'] = res[0]['org_id']
					return """
						<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; padding: 20px; text-align: center; border-radius: 20px;">
							<img src="static/assets/img/login1.gif" alt="Login Successful" style="width: 300px; ">
							<h3 style="color: red;"><b>Loading...</b></h3>
						</div>
						<script>
							setTimeout(function() {
								window.location.href = 'organisation_home';
							}, 4000); // Redirect after 2 seconds
					   </script>
					"""
				else:
					return "<script>alert('Your Account status is pending');window.location.href='login'</script>"

			elif  types=="bloodbank":
				q = "select * from `blood_banks` where `login_id`='%s' and `status`='Approved'"%(session['lid'])
				res = select(q)
				if res:
					session['b_id'] = res[0]['bank_id']
					# return redirect(url_for('bloodbank.bloodbank_home'))
					return """
						<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; padding: 20px; text-align: center; border-radius: 20px;">
							<img src="static/assets/img/login1.gif" alt="Login Successful" style="width: 300px; ">
							<h3 style="color: red;"><b>Login Successful...Loading...</b></h3>
						</div>
						<script>
							setTimeout(function() {
								window.location.href = 'bloodbank_home';
							}, 4000); // Redirect after 2 seconds
					   </script>
					"""
				else:
					return "<script>alert('Your Account status is pending');window.location.href='login'</script>"
										
			else:
				return """
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; padding: 20px; text-align: center; border-radius: 20px;">
        <img src="static/assets/img/login1.gif" alt="Login Successful" style="width: 300px; ">
        <h3 style="color: red;"><b>Login Successful...Loading...</b></h3>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = 'admin_home';
        }, 4000); // Redirect after 2 seconds
    </script>
"""
	return render_template('public/login.html')

@public.route('/bloodbank_register',methods=['get','post'])
def bloodbank_register():

	if "register" in request.form:
		bank_name = request.form['bank_name']
		phone = request.form['phone']
		email = request.form['email']
		username = request.form['username']
		password = request.form['password']
		place = request.form['place']
		post = request.form['post']
		pin = request.form['pin'] 
		city = request.form['city']
		dist = request.form['dist']
		image = request.files['image']
		path = 'static/images/blood_bank/'+str(uuid.uuid4())+image.filename
		image.save(path)

		q = "SELECT username FROM login WHERE username='%s'"%(username)
		res = select(q)
		if res:
			print("user already exist with this username")
			return "<script>alert('User already exists with this username and password');window.location.href='bloodbank_register';</script>"
		else:
			q1 = "insert into login values(null,'%s','%s','bloodbank')"%(username,password)
			res = insert(q1)
			q2 = "insert into `blood_banks` values(null,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','pending')"%(res,path,bank_name,phone,email,place,post,pin,city,dist)
			insert(q2)
			# return redirect(url_for('public.login'))
			return """
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; padding: 20px; text-align: center; border-radius: 20px;">
        <img src="static/assets/img/login1.gif" alt="Registeration Successfull" style="width: 300px; ">
        <h3 style="color: red;"><b>Registration Successful</b></h3>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = 'login';
        }, 4000); // Redirect after 2 seconds
    </script>
"""

	return render_template('public/bloodbank_register.html')


@public.route('/user_register',methods=['get','post'])
def user_register():
	data={}
	q2 = "select * from blood_group"
	data['group'] = select(q2)

	if "addnew" in request.form:
		name =  request.form['name']
		username =  request.form['username']
		password =  request.form['password']
		phone =  request.form['phone']
		email =  request.form['email']
		place =  request.form['place']
		post =  request.form['post']
		pin =  request.form['pin']
		city =  request.form['city']
		dist =  request.form['dist']
		grp = request.form['grp']
		image = request.files['image']
		isdonor = "donor" if 'isdonor' in  request.form else "reciever"

		q = "SELECT username FROM login WHERE username='%s'"%(username)
		res=select(q)
		if res:
			print("user already exist with this username")
			return "<script>alert('User already exists with this username and password');window.location.href='user_register';</script>"
		else:
			q = "insert into `login` values(null,'%s','%s','%s')"%(username,password,isdonor)
			res= insert(q)

			if isdonor == "donor":
				path= 'static/images/donor/'+ str(uuid.uuid4())+ image.filename
				image.save(path)
				q2 = "insert into `users` values(null,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(res,grp,path,name,phone,email,place,post,pin,city,dist,isdonor)
				insert(q2)
				# return redirect(url_for('public.login'))
				return """
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; padding: 20px; text-align: center; border-radius: 20px;">
        <img src="static/assets/img/login1.gif" alt="Registeration Successfull" style="width: 300px;">
        <h3 style="color: red;"><b>Registration Successful</b></h3>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = 'login';
        }, 4000); // Redirect after 2 seconds
    </script>
"""
				
			else:
				path = 'static/images/recievers/'+ str(uuid.uuid4())+ image.filename
				image.save(path)
				q2 = "insert into `users` values(null,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(res,grp,path,name,phone,email,place,post,pin,city,dist,isdonor)
				insert(q2)
				return """
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; padding: 20px; text-align: center; border-radius: 20px;">
        <img src="static/assets/img/login1.gif" alt="Registeration Successfull" style="width: 300px;">
        <h3 style="color: red;"><b>Registration Successful</b></h3>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = 'login';
        }, 4000); // Redirect after 2 seconds
    </script>
"""
				# return redirect(url_for('public.login'))
	return render_template('public/user_register.html',data=data)

@public.route("/organisation_register",methods=['get','post'])
def organisation_register():
	data={}
	if 'submit' in request.form:
		username = request.form['username']
		password = request.form['password']
		name = request.form['name']
		phone = request.form['phone']
		email = request.form['email']
		place = request.form['place']
		post = request.form['post']
		pin = request.form['pin']
		city = request.form['city']
		district = request.form['district']
		

		image = request.files['image']
		path = "static/images/organisation/"+str(uuid.uuid4())+image.filename
		image.save(path)
		q = "insert into login values(null,'%s','%s','orgs')"%(username,password)
		res = insert(q)

		q1 = "insert into organisations values(null,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','pending')"%(res,path,name,phone,email,place,post,pin,city,district)
		insert(q1)

		return """
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; padding: 20px; text-align: center; border-radius: 20px;">
        <img src="static/assets/img/login1.gif" alt="Registeration Successfull" style="width: 300px;">
        <h3 style="color: red;"><b>Registration Successful</b></h3>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = 'login';
        }, 4000); // Redirect after 2 seconds
    </script>
"""
	return render_template('public/organisation_register.html' , data=data)



@public.route('/hospital_register', methods=['get','post'])
def hospital_register():
	if "register" in request.form:
		username = request.form['username']
		password = request.form['password']
		hospital_name = request.form['hospital_name']
		phone = request.form['phone']
		email = request.form['email']
		place = request.form['place']
		post = request.form['post']
		pin = request.form['pin']
		city = request.form['city']
		district = request.form['district']

		image = request.files['image']
		path = "static/images/hospital/"+str(uuid.uuid4())+image.filename
		image.save(path)

		q = "insert into login values(null,'%s','%s','hospital')"%(username,password)
		res = insert(q)

		q1 = "insert into hospitals values(null,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','pending')"%(res,path,hospital_name,phone,email,place,post,pin,city,district)
		insert(q1)

		return """
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; padding: 20px; text-align: center; border-radius: 20px;">
        <img src="static/assets/img/login1.gif" alt="Registeration Successfull" style="width: 300px;">
        <h3 style="color: red;"><b>Registration Successful</b></h3>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = 'login';
        }, 4000); // Redirect after 2 seconds
    </script>
"""
	return render_template('public/hospital_register.html')

